<!DOCTYPE HTML>
<html>
	<head>
		<title>Flow Query For Tserver</title>
		<meta charset="utf-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1" />
		<!--[if lte IE 8]><script src="assets/js/ie/html5shiv.js"></script><![endif]-->
		<link rel="stylesheet" href="assets/css/main.css" />
		<!--[if lte IE 8]><link rel="stylesheet" href="assets/css/ie8.css" /><![endif]-->
		<!--[if lte IE 9]><link rel="stylesheet" href="assets/css/ie9.css" /><![endif]-->
	</head>
	<body class="loading">
		<div id="wrapper">
			<div id="bg"></div>
			<div id="overlay"></div>
			<div id="main">

				<!-- Header -->
					<header id="header">
						<h1>Flow Query</h1>
						<p>Flow Query For Tserver</p>
<?php
include("../api.inc.php");
$u = daddslashes($_GET['user']);
$res = $DB->get_row("SELECT * FROM `openvpn` where `iuser`='{$u}' limit 1");
$d2 = ceil(($res['endtime'] - time()) / 60 / 60 / 24);
if (!$res) 
{
echo '<form name="input" action="index.php"  method="get">
      <input type="text" name="user" style="color:#6699ee;background-color: rgba(0, 0, 0, 0.5)"  placeholder="用户名" /></p>
      <input type="submit" style="color:#FFFFFF;background-color: rgba(0, 0, 0, 0.5);width:50px;height:30px"  value="查 询" />
      </form>' ;
} 
else 
{	
echo '<form  role="form" method="POST" class="navbar-form navbar-left"  >
      <div class="form-group"> 
      <input type="text" class="form-control" name="km" style="color:#6699ee;background-color: rgba(0, 0, 0, 0.5)" placeholder="请输入充值卡密"></div>
	  <button type="submit" style="color:#FFFFFF;background-color: rgba(0, 0, 0, 0.5)" class="btn btn-default">确定充值</button>
	  </form>';
if($_POST['km'])
    { 
    $km = daddslashes($_POST['km']); 
    $myrow=$DB->get_row("select * from auth_kms where kind=1 and km='$km' limit 1"); 
    if(!$myrow)
        { 
        exit("<script language='javascript'>alert('此充值卡密不存在');
        history.go(-1);</script>"); 
        }
        elseif($myrow['isuse']==1)
        { 
        exit("<script language='javascript'>alert('此充值卡密已被使用');history.go(-1);</script>");
        }
        else
        { 
        $duetime = ($res['endtime'] < time() ? time() : $res['endtime']) + $myrow['value']*24*60*60; 
        $addll = $myrow['values']*1024*1024*1024; 
        if($res['endtime'] < time())
            { 
            $sql="update `openvpn` set `isent`='0',`irecv`='0',`maxll`='{$addll}',`endtime`='{$duetime}',`dlid`='{$myrow['daili']}',`i`='1' where `iuser`='{$u}'"; 
            if($DB->query($sql))
			    { 
		        $DB->query("update `auth_kms` set `isuse` ='1',`user` ='$u',`usetime` ='$date' where `id`='{$myrow['id']}'"); 
                wlog('账号激活','用户'.$u.'使用激活码'.$km.'开通账号['.$date.']'); exit("<script language='javascript'>alert('充值成功！');
                history.go(-1);</script>");
                }
                else
                { 
                exit("<script language='javascript'>alert('充值失败！');history.go(-1);</script>");
                }
            }
            else
		    { 
	        $sql="update `openvpn` set `maxll`=`maxll` + '{$addll}',`endtime`='{$duetime}',`dlid`='{$myrow['daili']}',`i`='1' where `iuser`='{$u}'"; 
            if($DB->query($sql))
                {
                $DB->query("update `auth_kms` set `isuse` ='1',`user` ='$u',`usetime` ='$date' where `id`='{$myrow['id']}'"); 
                wlog('账号激活','用户'.$u.'使用激活码'.$km.'续费账号['.$date.']'); 
                exit("<script language='javascript'>alert('充值成功！');history.go(-1);</script>");
                }
                else
                { 
                exit("<script language='javascript'>alert('充值失败！');
                history.go(-1);</script>");
                } 
            } 
        } 
    } 
	echo "<p>账号：" . $res['iuser'];
	echo "</p>发送：" . round($res['isent'] / 1024 / 1024);
	echo "MB</p>接收：" . round($res['irecv'] / 1024 / 1024);
    echo "MB</p>总量：" . round($res['maxll'] / 1024 / 1024);
	echo "MB</p>剩余：" . round(($res['maxll'] - $res['isent'] - $res['irecv']) / 1024 / 1024);
	echo "</p>注册时间：" . date('Y-m-d', $res['starttime']);
	echo "</p>到期时间：" . date('Y-m-d', $res['endtime']);
	echo "</p>剩余天数：" . $d2;
	echo '</p>当前在线的人数：';
	     $file_path = '../res/openvpn-status.txt';
         $line = 0 ;
         $fp = fopen($file_path , 'r') or die("open file failure!"); 
         if($fp)
		 { 
             while(stream_get_line($fp,8192,"\n"))
		     { 
             $line++; 
             } 
         fclose($fp);
         } 
    echo ($line-8)/2;
}				
?>
	
	
					</header>


				<!-- Footer -->
					<footer id="footer">
						<span class="copyright">Copyright © 2016 <a href="http://openvpnconnect.win">Wzb</a> All Rights Reserved.</span><script language="javascript" type="text/javascript" src="http://js.users.51.la/18908145.js"></script>
<noscript><a href="http://www.51.la/?18908145" target="_blank"><img alt="&#x6211;&#x8981;&#x5566;&#x514D;&#x8D39;&#x7EDF;&#x8BA1;" src="http://img.users.51.la/18908145.asp" style="border:none" /></a></noscript>
                    </footer>

			</div>
		</div>
		<!--[if lte IE 8]><script src="assets/js/ie/respond.min.js"></script><![endif]-->
		<script>
			window.onload = function() { document.body.className = ''; }
			window.ontouchmove = function() { return false; }
			window.onorientationchange = function() { document.body.scrollTop = 0; }
		</script>
		<div style="text-align:center;clear:both;">
<script src="/gg_bd_ad_720x90-2.js" type="text/javascript"></script>
<script src="/follow.js" type="text/javascript"></script>
</div>
	</body>
</html>